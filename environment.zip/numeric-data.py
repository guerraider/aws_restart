print("Python has three numeric types: int, float, and complex")Value

myValue = 1
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the dados type " + str(type(myValue)))
